#include <stdio.h>

int main(int argc, char **argv) {

	for(int i=0; i < 15; i++){

		printf("\n#%d: FSE2020-1 Angel Hernandez", i+1);

	}


	return 0;
}
