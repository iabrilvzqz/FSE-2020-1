#include <stdio.h>
#include <stdlib.h>
#define ROJO "\x1b[31m"
#define AZUL "\x1b[34m"
#define VERDE "\x1b[32m"

int main(int argc, char **argv) {
	int num = atoi(argv[1]);
	
	for(int i=0; i < num; i++){

		if(i % 3 == 0)
			printf(ROJO "\n#%d: FSE2020-1 Angel Hernandez", i+1);
		else if(i % 2 == 0)
			printf(VERDE "\n#%d: FSE2020-1 Angel Hernandez", i+1);
		else 
			printf(AZUL "\n#%d: FSE2020-1 Angel Hernandez", i+1);
	}
	return 0;
}
